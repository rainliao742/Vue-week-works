1.專案樣式
 -導入bootstrap v
 -修改變數 v
 -icon,Bootstrap icon v

2.建立路由
 -首頁 v
 -產品列表 v
 -單一產品 v
 -NavBar
 -Footer
 
3.版型套版 Vue Cli

4.頁面製作
 -首頁 v
 -產品列表
 -單一產品
 -NavBar

# week7-homework

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
