<template>
  <div class="bg-dark" >
    <div class="container">
      <div
        class="d-flex align-items-center justify-content-between text-white py-4"
      style="min-height:150px" >
        <p class="mb-0 w-50">© 2022 LOGO 繁果藝術 All Rights Reserved.</p>

        <ul class="d-flex list-unstyled mb-0 h4">
          <li class="text-center">
            <a href="#" class="text-white ms-3"
              ><i class="bi bi-facebook"></i>
            </a>
          </li>
          <li>
            <a href="#" class="text-white ms-3 text-center"
              ><i class="bi bi-line"></i>
            </a>
          </li>
        </ul>
        <p class="mb-0 text-end w-100">此站為測試使用</p>
      </div>
    </div>
  </div>
</template>
