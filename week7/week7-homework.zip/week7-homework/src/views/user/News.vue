<template>
  <div class="container-fluid">
      <h3>news = article</h3>
  </div>
</template>